Sebelum di Install, jangan lupa untuk mengubah konfigurasi koneksi pada file 'Connections/sispak.php' dan 'grafik.php'

-----

Di kembangkan oleh :

M. Nassurohman 
Pristi Sukmasetya 	
Auliansa Muhammad 
Ihda Husnayain 		
Danialdi Wahyu	 	
	
