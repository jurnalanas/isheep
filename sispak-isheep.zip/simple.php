<?php include 'inc/header.php'; ?>

		<div class="row">
			<div class="col-lg-12">
				<h1>Heading Text Goes Here</h1>
				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus.</p>
			</div>
		</div>
		<div id="sitefooter" class="row">
			<div class="col-lg-12">
				<hr>
				<p class="center">
					<small>© 2013 Your Name</small>
				</p>
				<p class="social-links center">
					<a href="https://www.facebook.com/" target="_blank" data-toggle="tooltip" data-placement="top" title="" data-original-title="Facebook">
						<i class="icon-facebook">
						</i>
					</a> &nbsp; 
					<a href="https://twitter.com/" target="_blank" data-toggle="tooltip" data-placement="top" title="" data-original-title="Twitter">
						<i class="icon-twitter">
						</i>
					</a> &nbsp; 
					<a href="mailto:" target="_blank" data-toggle="tooltip" data-placement="top" title="" data-original-title="Email">
						<i class="icon-envelope-alt">
						</i>
					</a>
				</p>
			</div>
		</div>
	<?php include 'inc/footer.php'; ?>