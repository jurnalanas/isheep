<?php include 'inc/header4.php'; ?>

		<div class="row">
			<div class="col-lg-12">
				<div class="topcover">
					<img src="assets/laptop.jpg" alt="" class="mg1">   
					<div class="header-caption center overimg">
					<h3>Meet the Team</h3>
					<p>Project ini merupakan salah satu tugas kuliah Ilmu Komputer IPB dalam mata kuliah Sistem Pakar.</p>
					</div>
				</div>
			</div>
		</div>
		<!-- <div class="row">
			<div class="col-lg-12">
				<div class="display center">
					<h2>Meet the Team</h2>
					<h3>Project ini merupakan salah satu tugas kuliah Ilmu Komputer IPB dalam mata kuliah Sistem Pakar.</h3>
				</div>
			</div>
		</div> -->
		<div class="row">
			<div class="col-lg-12">
				<hr>
			</div>
		</div>
		       
		<div class="row">
			
			<div class="col-lg-6">
			<div class="col-lg-3">
				<div>
					<img src="assets/pak-agik.jpg" class="thumbnail img-circle mg2" style="padding: 6px;">
				</div>
			</div>
				<div class="panel panel-success">
					<div class="panel-heading">
					<h5 class="panel-title">Prof. Dr. drh. Agik Suprayogi, M.Sc</h5>
					</div>
					<div class="panel-body">
						<p>Bapak Prof. Agik merupakan pakar yang membimbing tim dalam project ini. Beliau adalah dosen di Fakultas Kedokteran Hewan IPB, spesialisasi Lingkungan dan Penyakit pada Hewan Ternak.
</p>
					
					</div>
				</div>
				
					
			</div>
				<div class="col-lg-6">
			<div class="col-lg-3">
				<div>
					<img src="assets/anas.jpg" class="thumbnail img-circle mg2" style="padding: 4px;">
				</div>
			</div>
				<div class="panel panel-success">
					<div class="panel-heading">
					<h5 class="panel-title">Muhammad Nasrurrohman</h5>
					</div>
					<div class="panel-body">
						<p><em>A happy coder who loves build simple yet awesome app that improve people’s lives.</em></p>
						<p>Mahasiswa Ilmu Komputer IPB angkatan 48. Pandai menabung dan tidak sombong.</p>
				<p class="right">
				<a href="http://facebook.com/oianas" target="_blank">
						<i class="icon-facebook social">
						</i>
					</a> &nbsp; 
					<a href="https://plus.google.com/" target="_blank">
						<i class="icon-google-plus social">
						</i>
					</a> &nbsp; 
					<a href="http://twitter.com/anasbladz" target="_blank">
						<i class="icon-twitter social">
						</i>
					</a> &nbsp; 
					
					<a href="http://linkedin.com/jurnalanas" target="_blank">
						<i class="icon-linkedin social">
						</i>
					</a> &nbsp; 
					
				</p>
					</div>
				</div>
				
					
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
			</div>
		</div>
		<div class="row">
			
			<div class="col-lg-6">
			<div class="col-lg-3">
				<div>
					<img src="assets/pristy.jpeg" class="thumbnail img-circle mg2" style="padding: 6px;">
				</div>
			</div>
				<div class="panel panel-success">
					<div class="panel-heading">
					<h5 class="panel-title">Pristi Sukmasetya</h5>
					</div>
					<div class="panel-body">
						<p>Mahasiswi Ilmu Komputer IPB angkatan 48.</p>
					<p class="right">
				<a href="http://facebook.com/" target="_blank">
						<i class="icon-facebook social">
						</i>
					</a> &nbsp; 
					<a href="https://plus.google.com/" target="_blank">
						<i class="icon-google-plus social">
						</i>
					</a> &nbsp; 
					<a href="http://twitter.com/" target="_blank">
						<i class="icon-twitter social">
						</i>
					</a> &nbsp; 
					
					<a href="http://linkedin.com/" target="_blank">
						<i class="icon-linkedin social">
						</i>
					</a> &nbsp; 
					
				</p>
					</div>
				</div>
				
					
			</div>
				<div class="col-lg-6">
			<div class="col-lg-3">
				<div>
					<img src="assets/aul.png" class="thumbnail img-circle mg2" style="padding: 4px;">
				</div>
			</div>
				<div class="panel panel-success">
					<div class="panel-heading">
					<h5 class="panel-title">Auliansa Muhammad</h5>
					</div>
					<div class="panel-body">
						<p>Mahasiswa Ilmu Komputer IPB angkatan 48.</p>
				<p class="right">
				<a href="http://facebook.com/" target="_blank">
						<i class="icon-facebook social">
						</i>
					</a> &nbsp; 
					<a href="https://plus.google.com/" target="_blank">
						<i class="icon-google-plus social">
						</i>
					</a> &nbsp; 
					<a href="http://twitter.com/" target="_blank">
						<i class="icon-twitter social">
						</i>
					</a> &nbsp; 
					
					<a href="http://linkedin.com/" target="_blank">
						<i class="icon-linkedin social">
						</i>
					</a> &nbsp; 
					
				</p>
					</div>
				</div>
				
					
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
			</div>
		</div>
		<div class="row">
			
			<div class="col-lg-6">
			<div class="col-lg-3">
				<div>
					<img src="assets/ihda.jpeg" class="thumbnail img-circle mg2" style="padding: 6px;">
				</div>
			</div>
				<div class="panel panel-success">
					<div class="panel-heading">
					<h5 class="panel-title">Ihda Husnayain	</h5>
					</div>
					<div class="panel-body">
						<p>Mahasiswi Ilmu Komputer IPB angkatan 48.</p>
					<p class="right">
				<a href="http://facebook.com/" target="_blank">
						<i class="icon-facebook social">
						</i>
					</a> &nbsp; 
					<a href="https://plus.google.com/" target="_blank">
						<i class="icon-google-plus social">
						</i>
					</a> &nbsp; 
					<a href="http://twitter.com/" target="_blank">
						<i class="icon-twitter social">
						</i>
					</a> &nbsp; 
					
					<a href="http://linkedin.com/" target="_blank">
						<i class="icon-linkedin social">
						</i>
					</a> &nbsp; 
					
				</p>
					</div>
				</div>
				
					
			</div>
				<div class="col-lg-6">
			<div class="col-lg-3">
				<div>
					<img src="assets/danil.jpeg" class="thumbnail img-circle mg2" style="padding: 4px;">
				</div>
			</div>
				<div class="panel panel-success">
					<div class="panel-heading">
					<h5 class="panel-title">Danialdi Wahyu P</h5>
					</div>
					<div class="panel-body">
						<p>Mahasiswa Ilmu Komputer IPB angkatan 48.</p>
				<p class="right">
				<a href="http://facebook.com/" target="_blank">
						<i class="icon-facebook social">
						</i>
					</a> &nbsp; 
					<a href="https://plus.google.com/" target="_blank">
						<i class="icon-google-plus social">
						</i>
					</a> &nbsp; 
					<a href="http://twitter.com/" target="_blank">
						<i class="icon-twitter social">
						</i>
					</a> &nbsp; 
					
					<a href="http://linkedin.com/" target="_blank">
						<i class="icon-linkedin social">
						</i>
					</a> &nbsp; 
					
				</p>
					</div>
				</div>
				
					
			</div>
		</div>


		<div id="sitefooter" class="row">
			<div class="col-lg-12">
				<hr>
				<p class="center">
					<small>© 2013 iSheep</small>
				</p>
				
			</div>
	<?php include 'inc/footer.php'; ?>