<?php include 'inc/header.php'; ?>

		


		<div class="row">
			<div class="col-lg-12">
				<div class="topcover">
					<div class="carousel slide mg1" id="cid_0">
						<ol class="carousel-indicators">
							<li class="active" data-target="#cid_0">
							</li>
							<li data-target="#cid_0">
							</li>
							<li data-target="#cid_0">
							</li>
						</ol>
						<div class="carousel-inner">
							<div class="item active">
								<img src="assets/195_yst1eg.jpg" alt="">
								<div class="carousel-caption">
									<div class="header-caption">
										<h3>Bootstrap 3 Template + Flat UI</h3>
										<br>
										<p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
										<br>
										<br>
									</div>
								</div>
							</div>
							<div class="item">
								<img src="assets/195_du6423.jpg" alt="">
								<div class="carousel-caption">
									<div class="header-caption">
										<h3>Second slide label</h3>
										<br>
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
										<br>
										<br>
									</div>
								</div>
							</div>
							<div class="item">
								<img src="assets/195_gekni4.jpg" alt="">
								<div class="carousel-caption">
									<div class="header-caption">
										<h3>Third slide label</h3>
										<br>
										<p>Praesent commodo cursus magna, vel scelerisque nisl.</p>
										<br>
										<br>
									</div>
								</div>
							</div>
						</div> 
						<a class="left carousel-control" href="#">
							<span class="icon-prev">
							</span>
						</a> 
						<a class="right carousel-control" href="#">
							<span class="icon-next">
							</span>
						</a>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
				<div class="display center">
					<h2>Beautiful content. Responsive.</h2>
					<h3>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h3>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
				<div class="center mg1">
					<a href="#" class="btn btn-primary btn-lg section">&nbsp; Your Link Here! &nbsp;</a>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
				<hr>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
				<div class="display center">
					<h2>Features Here</h2>
					<h3>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h3>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
				<p>
					Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus.
				</p>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-6">
				<div class="list">
					<div>
						<i class="icon icon-ok">
						</i>
						<h4>Feature Item</h4>
						<div class="section">Lorem ipsum dolor sit amet.</div>
					</div>
				</div> 
			</div>
			<div class="col-lg-6">
				<div class="list">
					<div>
						<i class="icon icon-ok">
						</i>
						<h4>Feature Item</h4>
						<div class="section">Lorem ipsum dolor sit amet.</div>
					</div>
				</div> 
			</div>
		</div>
		<div class="row">
			<div class="col-lg-6">
				<div class="list">
					<div>
						<i class="icon icon-ok">
						</i>
						<h4>Feature Item</h4>
						<div class="section">Lorem ipsum dolor sit amet.</div>
					</div>
				</div> 
			</div>
			<div class="col-lg-6">
				<div class="list">
					<div>
						<i class="icon icon-ok">
						</i>
						<h4>Feature Item</h4>
						<div class="section">Lorem ipsum dolor sit amet.</div>
					</div>
				</div> 
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
				<hr>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
				<div class="display center">
					<h2>
						You Will Love It!
					</h2>
					<h3>
					Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h3>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus.</p>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-6">
				<h3>Why our customers love it</h3>
				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
			</div>
			<div class="col-lg-6">
				<article class="flex-video mg2">
					<iframe width="560" height="315" src="http://player.vimeo.com/video/2203727">
					</iframe>
				</article>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
				<hr>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
				<div class="display center">
					<h2>
						Quick Preview
					</h2>
					<h3>
						Lorem Ipsum is simply dummy text of the printing and typesetting industry.
					</h3>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus.</p>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-6">
				<a href="assets/lg-195_nyjkm3.jpg" data-gal="prettyPhoto[gallery1]">
					<img src="assets/195_nyjkm3.jpg" alt="" class="mg3">
				</a>              
				<p class="image-caption">Lorem Ipsum is simply dummy text.</p>
			</div>
			<div class="col-lg-6">
				<a href="assets/lg-195_o8gjmr.jpg" data-gal="prettyPhoto[gallery1]">
					<img src="assets/195_o8gjmr.jpg" alt="" class="mg3">
				</a>
				<p class="image-caption">Vivamus leo ante, consectetur sit amet.</p>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
				<hr>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
				<div class="display center">
					<h2>Testimonials</h2>
					<h3>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h3>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-6">
				<div class="quote">
					<i class="icon-quote-left">
					</i>
					<div>
						<span class="section">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</span>
						<i class="icon-quote-right">
						</i>
					</div>
					<small class="section">by Albert Einstein</small>
				</div>
			</div>
			<div class="col-lg-6">
				<div class="quote">
					<i class="icon-quote-left">
					</i>
					<div>
						<span class="section">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</span>
						<i class="icon-quote-right">
						</i>
					</div>
					<small class="section">by Albert Einstein</small>
				</div>
			</div>
		</div>
		<div id="sitefooter" class="row">
			<div class="col-lg-12">
				<hr>
				<p class="center">
					<small>© 2013 Your Name</small>
				</p>
				<p class="social-links center">
					<a href="https://www.facebook.com/" target="_blank" data-toggle="tooltip" data-placement="top" title="" data-original-title="Facebook">
						<i class="icon-facebook">
						</i>
					</a> &nbsp; 
					<a href="https://twitter.com/" target="_blank" data-toggle="tooltip" data-placement="top" title="" data-original-title="Twitter">
						<i class="icon-twitter">
						</i>
					</a> &nbsp; 
					<a href="mailto:" target="_blank" data-toggle="tooltip" data-placement="top" title="" data-original-title="Email">
						<i class="icon-envelope-alt">
						</i>
					</a>
				</p>
			</div>
		</div>

<?php include 'inc/footer.php'; ?>